class Constants {
  static const absencesPath = 'assets/json_files/absences.json';
  static const membersPath = 'assets/json_files/members.json';
}
